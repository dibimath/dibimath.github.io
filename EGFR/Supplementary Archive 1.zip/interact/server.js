tremppi.interact.setServer = function () {
};