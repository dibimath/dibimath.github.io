tremppi.function.setServer = function () {
};