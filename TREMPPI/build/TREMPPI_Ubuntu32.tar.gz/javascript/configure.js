tremppi.setup = { 	server_port: 8080, 
	server_location: "localhost", 
	project_name: "test_project"
};